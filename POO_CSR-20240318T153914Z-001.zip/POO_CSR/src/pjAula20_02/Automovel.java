package pjAula20_02;

import java.util.Date;

/**
 * @author CaueSpalla
 * @data 20/02/2024
 *Classe de modelagem conceitual de automovel
 */
public class Automovel {
	//atribuos
	int renavam;
	String modelo;
	String cor;
	int ano;
	String frabricante;
	float valor;
	Date dataCompra;
	Boolean situacao;
	
	
	//M�todos
	public void inserir(){
		//todo: implementar
	}
	public void excluir(){
		//todo: implementar
	}
}
