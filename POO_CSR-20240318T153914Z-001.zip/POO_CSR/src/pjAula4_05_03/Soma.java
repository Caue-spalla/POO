/**
 * 
 */
package pjAula4_05_03;

/**
 * @author usuario
 *
 */
public class Soma extends OperacaoMatematica {

	@Override
	public double calcular(double a, double b) {
		return a+b;
	}

}
