package pjAula4_05_03;

public class Subtracao extends OperacaoMatematica {

	@Override
	public double calcular(double a, double b) {
		return a-b;
	}
}
